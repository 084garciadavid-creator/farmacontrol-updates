FarmaControl 0.1.1
Paquete de prueba para validar descarga HTTPS y verificación SHA-256.
No contiene instalador ni ejecuta ningún cambio en el sistema.
