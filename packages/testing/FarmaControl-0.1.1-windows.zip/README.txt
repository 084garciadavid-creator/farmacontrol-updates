FarmaControl 0.1.1 - staging validation package.
This package is intentionally not executable and must never be installed.
